#include "Fixed.hpp"

int main( void ) {

	Fixed a;
	Fixed const b( 19 );
	a = Fixed( 19 );
	int ai = 19;
	int bi = 19;

	std::cout << "my comparison returns: " << (a < b) << std::endl;
	std::cout << "comparison returns: " << (ai < bi) << std::endl;

	return 0;
}